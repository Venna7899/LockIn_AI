// LockIn AI service worker (Manifest V3, ES module).
// Owns: Google sign-in, Gemini jobs, block/unblock decisions, the Engagement Bar meter,
// radar progress and Supabase sync. The popup and content scripts talk to it via messages.
import { CONFIG, AREA_META, DEFAULT_SETTINGS, DEFAULT_EB, siteKey } from './lib/config.js';
import * as sb from './lib/supabase.js';
import * as gem from './lib/gemini.js';
import * as radar from './lib/radar.js';

// Content scripts (untrusted contexts) must never read storage, the Gemini key lives there.
try { chrome.storage.local.setAccessLevel({ accessLevel: 'TRUSTED_CONTEXTS' }).catch(() => {}); } catch { /* older Chrome */ }

const SHAPES = ['circle', 'diamond', 'triangle', 'hexagon'];
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

let lastSyncError = '';
const progressError = () => `Could not load your progress${lastSyncError ? ` (${lastSyncError})` : '. Check your connection'}.`;

// Quote theme -> radar color, so each calm-down screen borrows an area's color.
const THEME_AREA = {
  focus: 'focus', discipline: 'consistency', perseverance: 'consistency', resilience: 'consistency',
  ambition: 'ambition', motivation: 'ambition', courage: 'ambition',
  success: 'achievement', growth: 'achievement', confidence: 'achievement'
};

/* ------------------------------------------------------------------ */
/* Small utilities                                                     */
/* ------------------------------------------------------------------ */

let chain = Promise.resolve();
// Serializes read-modify-write cycles on storage so concurrent tabs can't clobber each other.
function withLock(fn) {
  const run = chain.then(() => fn());
  chain = run.catch(() => {});
  return run;
}

const push = (tabId, msg) => chrome.tabs.sendMessage(tabId, msg).catch(() => {});
async function pushAll(msg) {
  const tabs = await chrome.tabs.query({});
  await Promise.all(tabs.filter((t) => t.id != null).map((t) => push(t.id, msg)));
}

const isNeutral = (host) =>
  host.endsWith('.chromiumapp.org') ||
  CONFIG.NEUTRAL_HOSTS.some((h) => host === h || host.endsWith(`.${h}`));

const tabHost = new Map(); // tabId -> hostname, for the popup's live meter

async function loadRuntime() {
  const d = await chrome.storage.local.get(['session', 'geminiKey', 'goal', 'eb', 'settings']);
  const uid = d.session?.user?.id;
  return {
    ready: !!(d.session && d.geminiKey),
    session: d.session || null,
    key: d.geminiKey || '',
    goal: d.goal && d.goal.owner === uid ? d.goal : null,
    eb: { ...DEFAULT_EB, ...(d.eb || {}) },
    settings: { ...DEFAULT_SETTINGS, ...(d.settings || {}) }
  };
}

/* ------------------------------------------------------------------ */
/* Auth                                                                */
/* ------------------------------------------------------------------ */

let refreshing = null;
function getValidSession() {
  return chrome.storage.local.get('session').then(async ({ session }) => {
    if (!session) return null;
    if (session.expires_at - 60 > Date.now() / 1000) return session;
    refreshing ||= (async () => {
      try {
        const next = { ...session, ...(await sb.refreshSession(session.refresh_token)) };
        await chrome.storage.local.set({ session: next });
        return next;
      } catch (e) {
        if (e.status === 400 || e.status === 401) await doLogout({ push: false }); // token revoked
        return null;
      } finally { refreshing = null; }
    })();
    return refreshing;
  });
}

async function doLogin() {
  const redirectTo = chrome.identity.getRedirectURL();
  const responseUrl = await chrome.identity.launchWebAuthFlow({
    url: sb.buildGoogleAuthUrl(redirectTo),
    interactive: true
  });
  const tokens = sb.parseAuthRedirect(responseUrl);
  const user = await sb.fetchUser(tokens.access_token);
  const session = { ...tokens, user };
  await chrome.storage.local.set({ session });
  try { await withLock(() => pullProgress(session)); lastSyncError = ''; } catch (e) { lastSyncError = e?.message || ''; /* retried on next sync */ }
  try { await chrome.action.openPopup(); } catch { /* popup can't open without a focused window */ }
}

async function doLogout({ push: doPush = true } = {}) {
  if (doPush) { try { await pushIfDirty(); } catch { /* offline */ } }
  const { session } = await chrome.storage.local.get('session');
  if (session) sb.signOut(session.access_token);
  // The Gemini API key is deleted on every logout.
  await chrome.storage.local.remove(['session', 'geminiKey', 'progress', 'job', 'keyError']);
  await chrome.storage.session.clear();
}

/* ------------------------------------------------------------------ */
/* Radar progress (local-first, synced to Supabase)                    */
/* ------------------------------------------------------------------ */

// Must be called inside withLock.
async function pullProgress(session) {
  const { progress } = await chrome.storage.local.get('progress');
  const uid = session.user.id;
  if (progress?.owner === uid && progress.dirty) {
    await sb.upsertProgress(session, radar.toRow(progress));
    progress.dirty = false;
    await chrome.storage.local.set({ progress });
    return progress;
  }
  const remote = await sb.getProgress(session);
  const p = remote ? radar.fromRow(remote, uid) : radar.newProgress(uid);
  await chrome.storage.local.set({ progress: p });
  if (!remote) await sb.upsertProgress(session, radar.toRow(p)).catch(() => {});
  return p;
}

async function ensureProgress(session) {
  const { progress } = await chrome.storage.local.get('progress');
  if (progress?.owner === session.user.id) return progress;
  try {
    const p = await pullProgress(session);
    lastSyncError = '';
    return p;
  } catch (e) {
    lastSyncError = e?.message || 'unknown error';
    return null; // never invent zeros over real data
  }
}

function mutateProgress(fn) {
  return withLock(async () => {
    const { session } = await chrome.storage.local.get('session');
    if (!session) return null;
    let p = await ensureProgress(session);
    if (!p) return null;
    p = radar.rollover(p, radar.todayStr());
    fn(p);
    p.dirty = true;
    p.updatedAt = Date.now();
    await chrome.storage.local.set({ progress: p });
    return p;
  });
}

function pushIfDirty() {
  return withLock(async () => {
    const { progress } = await chrome.storage.local.get('progress');
    if (!progress?.dirty) return;
    const session = await getValidSession();
    if (!session || session.user.id !== progress.owner) return;
    await sb.upsertProgress(session, radar.toRow(progress));
    const fresh = (await chrome.storage.local.get('progress')).progress;
    if (fresh && fresh.updatedAt === progress.updatedAt) {
      fresh.dirty = false;
      await chrome.storage.local.set({ progress: fresh });
    }
  });
}

async function syncNow() {
  const session = await getValidSession();
  if (!session) return;
  await withLock(() => pullProgress(session));
}

/* ------------------------------------------------------------------ */
/* Goals                                                               */
/* ------------------------------------------------------------------ */

async function commitGoal(g) {
  const { session } = await chrome.storage.local.get('session');
  if (!session) throw new Error('Please sign in first.');
  const goal = {
    owner: session.user.id,
    title: String(g.title).slice(0, 80),
    description: String(g.description).slice(0, 600),
    difficulty: Math.min(100, Math.max(1, Math.round(Number(g.difficulty)))),
    keywords: Array.isArray(g.keywords) ? g.keywords.slice(0, 10) : [],
    aim: String(g.aim || '').slice(0, 200),
    source: g.source === 'generated' ? 'generated' : 'custom',
    createdAt: Date.now()
  };
  const p = await mutateProgress((pr) => radar.applyNewGoal(pr, goal.difficulty));
  if (!p) throw new Error(progressError());
  await chrome.storage.session.set({ verdicts: {} });
  await chrome.storage.local.set({ goal });
  pushIfDirty().catch(() => {});
}

async function deleteGoal() {
  await chrome.storage.session.set({ verdicts: {} });
  await chrome.storage.local.remove('goal');
}

async function completeGoal() {
  const { goal } = await chrome.storage.local.get('goal');
  if (!goal) return;
  const p = await mutateProgress((pr) => radar.applyGoalAchieved(pr, goal.difficulty));
  if (!p) throw new Error(progressError());
  await deleteGoal();
  pushIfDirty().catch(() => {});
}

/* ------------------------------------------------------------------ */
/* Gemini jobs (goal analysis / generation). Run here so they keep     */
/* retrying "behind the scenes" even if the popup is closed.           */
/* ------------------------------------------------------------------ */

let current = null; // { id, controller }

async function patchJob(id, patch) {
  const { job } = await chrome.storage.local.get('job');
  if (job?.id === id) await chrome.storage.local.set({ job: { ...job, ...patch } });
}

async function runJob(rec, controller) {
  const { geminiKey } = await chrome.storage.local.get('geminiKey');
  const fn = rec.kind === 'generate' ? gem.generateGoal : gem.analyzeGoal;
  try {
    const result = await fn(geminiKey, rec.input, {
      signal: controller.signal,
      onRetry: (n) => patchJob(rec.id, { attempts: n })
    });
    if (result.rejected) await patchJob(rec.id, { status: 'rejected' });
    else await patchJob(rec.id, {
      status: 'done',
      result: { ...result, aim: rec.input.aim || '', source: rec.kind === 'generate' ? 'generated' : 'custom' }
    });
  } catch (e) {
    if (e.code === 'aborted') return;
    if (e.code === 'blocked') await patchJob(rec.id, { status: 'rejected' });
    else {
      if (e.code === 'bad_key') await chrome.storage.local.set({ keyError: true });
      await patchJob(rec.id, {
        status: 'error',
        error: e.code === 'bad_key'
          ? 'Gemini rejected your API key. Update it in Settings.'
          : 'Something went wrong. Please try again.'
      });
    }
  } finally {
    if (current?.id === rec.id) current = null;
  }
}

async function startJob(job) {
  current?.controller.abort();
  const rec = {
    id: crypto.randomUUID(), kind: job.kind === 'generate' ? 'generate' : 'analyze',
    input: job.input || {}, status: 'running', attempts: 0, startedAt: Date.now()
  };
  const controller = new AbortController();
  current = { id: rec.id, controller };
  await chrome.storage.local.set({ job: rec });
  runJob(rec, controller);
}

async function cancelJob() {
  current?.controller.abort();
  current = null;
  await chrome.storage.local.remove('job');
}

// If the worker was restarted mid-job, pick the job back up.
(async () => {
  const { job } = await chrome.storage.local.get('job');
  if (job?.status === 'running' && !current) {
    const controller = new AbortController();
    current = { id: job.id, controller };
    runJob(job, controller);
  }
})();

/* ------------------------------------------------------------------ */
/* Content script registration                                         */
/* ------------------------------------------------------------------ */
// Site access is an OPTIONAL host permission: nothing is injected anywhere until the user
// grants it from the popup. The content script is then registered dynamically.

const CS_ID = 'lockin-content';
const CS_FILES = ['content/games.js', 'content/content.js'];
const ORIGINS = ['http://*/*', 'https://*/*'];

let csChain = Promise.resolve();
function syncContentScripts() {
  csChain = csChain.then(async () => {
    try {
      const access = await chrome.permissions.contains({ origins: ORIGINS });
      const reg = await chrome.scripting.getRegisteredContentScripts({ ids: [CS_ID] });
      if (access && !reg.length) {
        await chrome.scripting.registerContentScripts([{
          id: CS_ID, js: CS_FILES, matches: ORIGINS, runAt: 'document_start', allFrames: false, persistAcrossSessions: true
        }]);
        // tabs that were already open when access was granted
        const tabs = await chrome.tabs.query({ url: ORIGINS });
        await Promise.all(tabs.map((t) => chrome.scripting.executeScript({ target: { tabId: t.id }, files: CS_FILES }).catch(() => {})));
      } else if (!access && reg.length) {
        await chrome.scripting.unregisterContentScripts({ ids: [CS_ID] });
      }
    } catch { /* retried on next wake-up */ }
  });
  return csChain;
}

chrome.permissions.onAdded.addListener(syncContentScripts);
chrome.permissions.onRemoved.addListener(syncContentScripts);

/* ------------------------------------------------------------------ */
/* Block decisions                                                     */
/* ------------------------------------------------------------------ */

let quotes = null;
async function pickQuote() {
  if (!quotes) quotes = await (await fetch(chrome.runtime.getURL('data/quotes.json'))).json();
  return quotes[Math.floor(Math.random() * quotes.length)];
}

async function pushBlock(tabId, rt, reason, page) {
  const quote = await pickQuote();
  const area = THEME_AREA[quote.c] || 'focus';
  const enabled = (rt.settings.games || []).length ? rt.settings.games : DEFAULT_SETTINGS.games;
  const shape = SHAPES.includes(rt.settings.shape) ? rt.settings.shape : SHAPES[Math.floor(Math.random() * SHAPES.length)];
  await push(tabId, {
    type: 'block',
    reason,
    host: siteKey(page.host),
    goalTitle: rt.goal?.title || '',
    category: quote.c.charAt(0).toUpperCase() + quote.c.slice(1),
    quote: quote.q,
    color: AREA_META[area].color,
    shape,
    game: enabled[Math.floor(Math.random() * enabled.length)]
  });
}

const titleKey = (page) => `ht:${page.host}|${page.title}`;

async function getVerdict(page, full) {
  const { verdicts = {} } = await chrome.storage.session.get('verdicts');
  const fresh = (e) => e && Date.now() - e.ts <= CONFIG.VERDICT_TTL_MS;
  const e = verdicts[page.url];
  if (fresh(e) && !(full && !e.user && e.title !== page.title)) return e.v; // title changed (SPA): re-check
  if (full && page.title) {
    const t = verdicts[titleKey(page)];
    if (fresh(t)) return t.v; // same site + same title as a page already judged
  }
  return undefined;
}

function setVerdict(page, entry) {
  return withLock(async () => {
    const { verdicts = {} } = await chrome.storage.session.get('verdicts');
    verdicts[page.url] = entry;
    if (page.title) verdicts[titleKey(page)] = { v: entry.v, ts: entry.ts };
    const keys = Object.keys(verdicts);
    if (keys.length > 500) {
      keys.sort((a, b) => verdicts[a].ts - verdicts[b].ts).slice(0, 150).forEach((k) => delete verdicts[k]);
    }
    await chrome.storage.session.set({ verdicts });
  });
}

// Gemini calls are serialized and spaced out to stay inside free-tier rate limits.
let aiQueue = Promise.resolve();
function enqueueAI(fn) {
  const run = aiQueue.then(fn);
  aiQueue = run.catch(() => {}).then(() => sleep(1200));
  return run;
}

const inflight = new Set();
async function checkGoalPage(tabId, page, rt, retry = 0) {
  const id = `${page.url}|${page.title}`;
  if (inflight.has(id)) return;
  inflight.add(id);
  let retrying = false;
  try {
    let path = '/';
    try { path = new URL(page.url).pathname; } catch { /* keep default */ }
    const relevant = await enqueueAI(() => gem.checkPage(
      rt.key, rt.goal, { host: page.host, path, title: page.title, desc: page.desc }, { maxAttempts: 3 }
    ));
    const now = await loadRuntime();
    if (!now.ready || !now.goal || now.goal.createdAt !== rt.goal.createdAt) return; // goal changed meanwhile
    await setVerdict(page, { v: relevant ? 'on' : 'off', title: page.title, ts: Date.now() });
    if (relevant) await push(tabId, { type: 'unblock' });
    else await pushBlock(tabId, now, 'goal', page);
  } catch (e) {
    if (e.code === 'bad_key') { await chrome.storage.local.set({ keyError: true }); return; }
    // Gemini is busy or offline: don't block, keep trying quietly a few times.
    if (retry < 3) {
      retrying = true;
      setTimeout(() => {
        inflight.delete(id);
        loadRuntime().then((r) => r.ready && r.goal && checkGoalPage(tabId, page, r, retry + 1));
      }, 15000 * 2 ** retry);
    }
  } finally {
    if (!retrying) inflight.delete(id);
  }
}

async function onPageCheck(msg, sender) {
  const tabId = sender.tab?.id;
  if (tabId == null) return;
  const page = msg.page;
  tabHost.set(tabId, page.host);
  const rt = await loadRuntime();

  if (!rt.ready || isNeutral(page.host) || (!rt.goal && !rt.eb.running)) {
    await push(tabId, { type: 'unblock' });
    return;
  }
  if (rt.eb.running) {
    const { locks = {} } = await chrome.storage.session.get('locks');
    if (locks[siteKey(page.host)]) { await pushBlock(tabId, rt, 'engagement', page); return; }
  }
  if (rt.goal) {
    const v = await getVerdict(page, !!msg.full);
    if (v === 'off') { await pushBlock(tabId, rt, 'goal', page); return; }
    if (v === undefined) {
      if (msg.full) checkGoalPage(tabId, page, rt); // verdict arrives later via push
      return;
    }
  }
  await push(tabId, { type: 'unblock' });
}

/* ------------------------------------------------------------------ */
/* Engagement Bar                                                      */
/* ------------------------------------------------------------------ */

function bumpMeter(host, s, threshold) {
  const E = CONFIG.EB;
  return withLock(async () => {
    const { meters = {}, locks = {} } = await chrome.storage.session.get(['meters', 'locks']);
    const now = Date.now();
    const m = meters[host] || { v: 0, t: now };

    const awayMin = Math.max(0, (now - m.t) / 60000 - (s.elapsedSec || 0) / 60);
    const delta =
      (s.activeSec / 60) * E.PTS_PER_ACTIVE_MIN +
      Math.min(s.screens || 0, 12) * E.PTS_PER_SCREEN +
      Math.min(s.feedLoads || 0, 3) * E.PTS_PER_FEED_LOAD +
      ((s.videoSec || 0) / 60) * E.PTS_PER_VIDEO_MIN +
      ((s.shortSec || 0) / 60) * E.PTS_PER_SHORTFORM_MIN +
      Math.min(s.clicks || 0, 10) * E.PTS_PER_CLICK;

    const v = Math.min(100, Math.max(0, m.v - awayMin * E.DECAY_PER_MIN + delta));
    meters[host] = { v, t: now };
    if (v >= threshold && !locks[host]) locks[host] = now;
    await chrome.storage.session.set({ meters, locks });
    return { v, locked: !!locks[host] };
  });
}

async function onSample(msg, sender) {
  const tabId = sender.tab?.id;
  if (tabId == null) return;
  const page = msg.page;
  tabHost.set(tabId, page.host);
  const rt = await loadRuntime();
  if (!rt.ready || isNeutral(page.host) || (!rt.goal && !rt.eb.running)) return;

  let onGoal = true;
  if (rt.goal) onGoal = (await getVerdict(page, true)) === 'on'; // unknown = not counted yet

  let calm = true;
  if (rt.eb.running) {
    const r = await bumpMeter(siteKey(page.host), msg, rt.eb.threshold);
    if (r.locked) { calm = false; await pushBlock(tabId, rt, 'engagement', page); }
  }
  // Focus: only active, on-task time on pages that weren't blocked.
  if (onGoal && calm && msg.activeSec > 0) await mutateProgress((p) => radar.addFocus(p, msg.activeSec));
}

async function onResume(msg, sender) {
  const tabId = sender.tab?.id;
  const page = msg.page;
  if (msg.reason === 'engagement') {
    const rt = await loadRuntime();
    await withLock(async () => {
      const { meters = {}, locks = {} } = await chrome.storage.session.get(['meters', 'locks']);
      const site = siteKey(page.host);
      delete locks[site];
      meters[site] = { v: rt.eb.threshold * CONFIG.EB.RESUME_FRACTION, t: Date.now() };
      await chrome.storage.session.set({ meters, locks });
    });
  } else if (msg.reason === 'goal' && msg.allow) {
    await setVerdict(page, { v: 'on', title: page.title, ts: Date.now(), user: true });
  }
  if (tabId != null) await push(tabId, { type: 'unblock' });
}

async function meterForTab(tabId) {
  const host = tabHost.get(tabId) || null;
  if (!host) return { ok: true, host: null };
  const { meters = {}, locks = {} } = await chrome.storage.session.get(['meters', 'locks']);
  const site = siteKey(host);
  return { ok: true, host: site, value: Math.round(meters[site]?.v || 0), locked: !!locks[site] };
}

/* ------------------------------------------------------------------ */
/* Messaging + lifecycle                                               */
/* ------------------------------------------------------------------ */

async function handle(msg, sender) {
  switch (msg?.type) {
    case 'page_check': await onPageCheck(msg, sender); return { ok: true };
    case 'sample':     await onSample(msg, sender); return { ok: true };
    case 'resume':     await onResume(msg, sender); return { ok: true };
    case 'leave':
      if (sender.tab?.id != null) await chrome.tabs.update(sender.tab.id, { url: 'chrome://newtab/' });
      return { ok: true };

    case 'auth:login':  await doLogin(); return { ok: true };
    case 'auth:logout': await doLogout(); return { ok: true };
    case 'sync:pull':   await syncNow(); return { ok: true };

    case 'goal:commit':   await commitGoal(msg.goal); return { ok: true };
    case 'goal:delete':   await deleteGoal(); return { ok: true };
    case 'goal:complete': await completeGoal(); return { ok: true };

    case 'job:start':  await startJob(msg.job); return { ok: true };
    case 'job:cancel': await cancelJob(); return { ok: true };

    case 'eb:meter': return meterForTab(msg.tabId);
    default: return { ok: false, error: 'unknown message' };
  }
}

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  handle(msg, sender).then(sendResponse, (e) => sendResponse({ ok: false, error: e?.message || String(e) }));
  return true;
});

// Re-evaluate every open tab whenever something that affects blocking changes.
chrome.storage.onChanged.addListener((changes, area) => {
  if (area !== 'local') return;
  if (changes.eb) {
    const a = { ...DEFAULT_EB, ...(changes.eb.oldValue || {}) };
    const b = { ...DEFAULT_EB, ...(changes.eb.newValue || {}) };
    if (a.running !== b.running || a.threshold !== b.threshold) {
      chrome.storage.session.set(b.running ? { locks: {} } : { locks: {}, meters: {} });
    }
  }
  if (changes.session || changes.geminiKey || changes.goal || changes.eb) {
    pushAll({ type: 'recheck' });
  }
});

async function ensureAlarms() {
  if (!(await chrome.alarms.get('sync'))) chrome.alarms.create('sync', { periodInMinutes: 1 });
  if (!(await chrome.alarms.get('daily'))) chrome.alarms.create('daily', { periodInMinutes: 60 });
}

chrome.alarms.onAlarm.addListener(async (alarm) => {
  try {
    if (alarm.name === 'sync') await pushIfDirty();
    if (alarm.name === 'daily') {
      const { session } = await chrome.storage.local.get('session');
      if (session) await mutateProgress(() => {}); // closes finished days so Consistency stays honest
    }
  } catch { /* offline: try again next minute */ }
});

chrome.runtime.onInstalled.addListener(() => { ensureAlarms(); syncContentScripts(); });
chrome.runtime.onStartup.addListener(() => { ensureAlarms(); syncContentScripts(); syncNow().catch(() => {}); });
ensureAlarms();
syncContentScripts();
