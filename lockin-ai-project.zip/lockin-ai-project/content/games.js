// Calm-down spatial puzzles shown inside the block overlay.
// Loaded before content.js (same isolated world) and exposes self.__lockinGames.
(() => {
  'use strict';

  const h = (tag, props = {}, ...kids) => {
    const el = document.createElement(tag);
    for (const [k, v] of Object.entries(props)) {
      if (k === 'class') el.className = v;
      else if (k === 'style') el.style.cssText = v;
      else if (k.startsWith('on')) el.addEventListener(k.slice(2), v);
      else el.setAttribute(k, v);
    }
    for (const kid of kids.flat()) if (kid != null) el.append(kid.nodeType ? kid : document.createTextNode(String(kid)));
    return el;
  };
  const rand = (n) => Math.floor(Math.random() * n);
  const N = 3;

  /* ---------- 1. Slide: put the tiles back in order ---------- */
  function slide(box, onSolved) {
    const size = N * N;
    const tiles = Array.from({ length: size }, (_, i) => (i + 1) % size); // 1..8, 0 = gap
    const nbrs = (i) => {
      const r = Math.floor(i / N), c = i % N, out = [];
      if (r > 0) out.push(i - N);
      if (r < N - 1) out.push(i + N);
      if (c > 0) out.push(i - 1);
      if (c < N - 1) out.push(i + 1);
      return out;
    };
    const isSolved = () => tiles.every((t, i) => t === (i + 1) % size);
    const swap = (a, b) => { [tiles[a], tiles[b]] = [tiles[b], tiles[a]]; };

    // scramble with legal moves so it is always solvable
    let gap = size - 1, last = -1;
    for (let i = 0; i < 22 || isSolved(); i++) {
      const options = nbrs(gap).filter((n) => n !== last);
      const next = options[rand(options.length)];
      swap(gap, next); last = gap; gap = next;
    }

    const board = h('div', { class: 'board', role: 'group', 'aria-label': 'Sliding puzzle' });
    let done = false;
    const render = () => {
      const g = tiles.indexOf(0);
      board.replaceChildren(...tiles.map((t, i) => {
        if (t === 0) return h('div', { class: 'tile blank' });
        return h('button', {
          class: 'tile', 'aria-label': `Tile ${t}`,
          onclick: () => {
            if (done || !nbrs(g).includes(i)) return;
            swap(g, i); render();
            if (isSolved()) { done = true; board.classList.add('solved'); onSolved(); }
          }
        }, t);
      }));
    };
    render();
    box.append(board);
  }

  /* ---------- 2. Lights: turn every lamp off ---------- */
  function lights(box, onSolved) {
    const on = Array(N * N).fill(false);
    const press = (i, arr) => {
      const r = Math.floor(i / N), c = i % N;
      [[0, 0], [1, 0], [-1, 0], [0, 1], [0, -1]].forEach(([dr, dc]) => {
        const rr = r + dr, cc = c + dc;
        if (rr >= 0 && rr < N && cc >= 0 && cc < N) arr[rr * N + cc] = !arr[rr * N + cc];
      });
    };
    // scramble from the solved state, so it is always solvable
    do {
      on.fill(false);
      const count = 3 + rand(3);
      const pool = [...on.keys()];
      for (let k = 0; k < count; k++) press(pool.splice(rand(pool.length), 1)[0], on);
    } while (on.filter(Boolean).length < 2);

    const board = h('div', { class: 'board', role: 'group', 'aria-label': 'Lights puzzle' });
    let done = false;
    const render = () => {
      board.replaceChildren(...on.map((v, i) => h('button', {
        class: 'lamp' + (v ? ' on' : ''), 'aria-label': v ? 'Lamp on' : 'Lamp off',
        onclick: () => {
          if (done) return;
          press(i, on); render();
          if (on.every((x) => !x)) { done = true; board.classList.add('solved'); onSolved(); }
        }
      })));
    };
    render();
    box.append(board);
  }

  /* ---------- 3. Match: rotate the tiles until they copy the pattern ---------- */
  function match(box, onSolved) {
    const size = N * N;
    const target = Array.from({ length: size }, () => rand(4));
    let cur = target.map((t) => (t + rand(4)) % 4);
    while (cur.filter((c, i) => c !== target[i]).length < 5) {
      const i = rand(size);
      cur[i] = (target[i] + 1 + rand(3)) % 4;
    }

    const cell = (rot, props = {}) => h('button', { class: 'cell', ...props }, h('span', { class: 'q', style: `transform:rotate(${rot * 90}deg)` }));
    const preview = h('div', { class: 'preview', 'aria-label': 'Target pattern' },
      target.map((t) => h('div', { class: 'cell' }, h('span', { class: 'q', style: `transform:rotate(${t * 90}deg)` }))));
    const board = h('div', { class: 'board', role: 'group', 'aria-label': 'Rotate the tiles' });
    let done = false;
    const spin = [...cur]; // keeps rotating forward so the CSS transition never spins backwards
    const tileEls = cur.map((_, i) => {
      const el = cell(spin[i], { 'aria-label': 'Rotate tile' });
      el.addEventListener('click', () => {
        if (done) return;
        cur[i] = (cur[i] + 1) % 4;
        spin[i] += 1;
        el.firstChild.style.transform = `rotate(${spin[i] * 90}deg)`;
        if (cur.every((c, j) => c === target[j])) { done = true; board.classList.add('solved'); onSolved(); }
      });
      return el;
    });
    board.append(...tileEls);
    box.append(h('div', { class: 'match' }, h('div', { class: 'target' }, h('span', {}, 'Copy this'), preview), board));
  }

  self.__lockinGames = { h, slide, lights, match };
})();
