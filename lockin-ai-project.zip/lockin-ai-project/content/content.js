// LockIn AI content script.
// 1) reports how engaged you are on this page, 2) asks the service worker whether the page
// should be blocked, 3) draws the calm-down overlay. It never touches storage or the Gemini key.
(() => {
  'use strict';
  if (window.top !== window.self || window.__lockinLoaded) return;
  window.__lockinLoaded = true;

  const G = self.__lockinGames;
  const { h } = G;

  // keep in sync with CONFIG.EB in lib/config.js
  const SAMPLE_MS = 5000;
  const IDLE_MS = 60000;

  const timers = [];
  let alive = true;
  let overlay = null;

  /* ---------------- messaging ---------------- */

  const extOk = () => { try { return !!chrome.runtime?.id; } catch { return false; } };

  function send(msg) {
    if (!extOk()) { teardown(); return Promise.resolve(null); }
    return chrome.runtime.sendMessage(msg).catch(() => null);
  }

  function teardown() {
    if (!alive) return;
    alive = false;
    timers.forEach(clearInterval);
    hideOverlay();
  }

  /* ---------------- page info + checks ---------------- */

  const pageUrl = () => location.href.split('#')[0];
  const visible = () => document.visibilityState === 'visible';

  function info() {
    const d = document.querySelector('meta[name="description"],meta[property="og:description"]');
    return {
      url: pageUrl(),
      host: location.hostname,
      title: (document.title || '').slice(0, 160),
      desc: (d?.content || '').slice(0, 240)
    };
  }

  const check = (full) => send({ type: 'page_check', full, page: info() });

  let lastKey = '';
  let pendingRecheck = false;
  const pageKey = () => `${pageUrl()}|${document.title}`;

  check(false); // document_start: instant answer for pages that are already locked / known off-goal
  const onReady = () => {
    let waited = 0;
    const go = () => {
      if (!alive) return;
      if (!document.title && waited < 1600) { waited += 400; setTimeout(go, 400); return; } // SPAs set the title late
      lastKey = pageKey();
      if (visible()) check(true); else pendingRecheck = true; // background tabs are checked when you open them
    };
    go();
  };
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', onReady, { once: true });
  else onReady();

  // SPAs change URL/title without a reload; poll cheaply and re-check on change.
  timers.push(setInterval(() => {
    if (!alive || !visible()) return;
    const k = pageKey();
    if (k !== lastKey) { lastKey = k; check(true); }
  }, 2000));

  document.addEventListener('visibilitychange', () => {
    if (visible() && pendingRecheck) { pendingRecheck = false; check(true); }
  });

  chrome.runtime.onMessage.addListener((msg) => {
    if (!alive || !msg) return;
    if (msg.type === 'block') showOverlay(msg);
    else if (msg.type === 'unblock') hideOverlay();
    else if (msg.type === 'recheck') { if (visible()) check(true); else pendingRecheck = true; }
  });

  /* ---------------- engagement sampling ---------------- */

  const st = { lastInput: 0, scrollPx: 0, clicks: 0, lastScrollAt: 0, lastHeight: 0, lastTick: Date.now(), lastMove: 0 };
  const noteInput = () => { st.lastInput = Date.now(); };
  const lastTop = new WeakMap();

  ['keydown', 'wheel', 'touchstart'].forEach((t) => window.addEventListener(t, noteInput, { capture: true, passive: true }));
  window.addEventListener('pointerdown', () => { noteInput(); st.clicks++; }, { capture: true, passive: true });
  window.addEventListener('mousemove', () => {
    const now = Date.now();
    if (now - st.lastMove > 2000) { st.lastMove = now; noteInput(); }
  }, { capture: true, passive: true });
  document.addEventListener('scroll', (e) => {
    const t = e.target === document ? document.scrollingElement : e.target;
    if (!t || typeof t.scrollTop !== 'number') return;
    const prev = lastTop.get(t) ?? t.scrollTop;
    st.scrollPx += Math.abs(t.scrollTop - prev);
    lastTop.set(t, t.scrollTop);
    st.lastScrollAt = Date.now();
    noteInput();
  }, { capture: true, passive: true });

  // returns 0 (no video), 1 (video playing) or 2 (portrait, phone-shaped video: Shorts / Reels / TikTok)
  function videoState() {
    let state = 0;
    for (const v of document.querySelectorAll('video')) {
      if (v.paused || v.ended || v.readyState < 3 || !v.videoWidth) continue;
      const r = v.getBoundingClientRect();
      if (r.width > 120 && r.height > 120 && r.bottom > 0 && r.top < innerHeight) {
        if (v.videoHeight > v.videoWidth) return 2;
        state = 1;
      }
    }
    return state;
  }

  timers.push(setInterval(() => {
    if (!alive) return;
    const now = Date.now();
    const elapsedSec = Math.min(15, (now - st.lastTick) / 1000);
    st.lastTick = now;
    if (overlay || !visible() || !document.hasFocus()) {
      st.scrollPx = 0; st.clicks = 0;
      return;
    }
    const vs = videoState();
    const playing = vs > 0;
    const interacting = now - st.lastInput < IDLE_MS;
    const height = document.documentElement.scrollHeight;
    const grew = st.lastHeight && height - st.lastHeight > innerHeight * 0.5 && now - st.lastScrollAt < SAMPLE_MS + 1000;
    st.lastHeight = height;

    send({
      type: 'sample',
      page: info(),
      elapsedSec,
      activeSec: interacting || playing ? elapsedSec : 0,
      screens: st.scrollPx / Math.max(1, innerHeight),
      clicks: st.clicks,
      feedLoads: grew ? 1 : 0,
      videoSec: playing ? elapsedSec : 0,
      shortSec: vs === 2 ? elapsedSec : 0
    });
    st.scrollPx = 0; st.clicks = 0;
  }, SAMPLE_MS));

  /* ---------------- overlay ---------------- */

  const CSS = `
    :host { all: initial; }
    * { box-sizing: border-box; }
    .stage { position: fixed; inset: 0; background: var(--bg); color: var(--fg); overflow: hidden;
      --fg-soft: color-mix(in srgb, var(--fg) 16%, transparent);
      font-family: ui-rounded, "SF Pro Rounded", "Hiragino Maru Gothic ProN", "Nunito", "Segoe UI", system-ui, sans-serif; }
    .shape { position: absolute; background: var(--shape); transform: scale(0); will-change: transform; }
    .content { position: absolute; inset: 0; display: flex; flex-direction: column; justify-content: space-between;
      align-items: center; text-align: center; opacity: 0; transition: opacity .9s ease;
      padding: clamp(24px, 7vh, 72px) 24px clamp(20px, 5vh, 48px); }
    .content.show { opacity: 1; }
    .top { display: flex; flex-direction: column; align-items: center; gap: 18px; max-width: min(760px, 92vw); }
    .chip { padding: 7px 18px; border-radius: 999px; background: var(--fg-soft); font-weight: 700; font-size: 15px; }
    .quote { margin: 0; font-size: clamp(24px, 4.4vw, 46px); line-height: 1.2; font-weight: 750; text-wrap: balance; }
    .why { margin: 0; font-size: 15px; opacity: .78; max-width: 52ch; }
    .bottom { display: flex; flex-direction: column; align-items: center; gap: 16px; width: 100%; }
    .hint { margin: 0; font-size: 15px; font-weight: 600; opacity: .85; }
    .game { min-height: 100px; display: flex; justify-content: center; }
    .board { display: grid; grid-template-columns: repeat(3, 1fr); gap: 8px; width: min(246px, 62vw); aspect-ratio: 1; }
    .board.solved { animation: pop .6s ease; }
    @keyframes pop { 40% { transform: scale(1.06); } }
    .tile, .cell, .lamp { border: 0; padding: 0; cursor: pointer; color: var(--fg); font: inherit; }
    .tile { border-radius: 18px; background: var(--fg-soft); font-size: clamp(20px, 3.4vw, 28px); font-weight: 750;
      display: grid; place-items: center; transition: transform .12s ease; }
    .tile:hover { transform: scale(1.04); }
    .tile.blank { background: transparent; cursor: default; box-shadow: inset 0 0 0 2px var(--fg-soft); }
    .tile.blank:hover { transform: none; }
    .lamp { border-radius: 50%; background: transparent; box-shadow: inset 0 0 0 3px var(--fg); transition: background .2s ease; }
    .lamp.on { background: var(--fg); }
    .cell { position: relative; overflow: hidden; border-radius: 18px; background: var(--fg-soft); display: block; }
    .cell .q { position: absolute; inset: 0; background: radial-gradient(circle at 0 0, var(--fg) 62%, transparent 63%);
      transition: transform .28s cubic-bezier(.3, 1.5, .5, 1); }
    .match { display: flex; align-items: center; gap: 22px; }
    .target { display: flex; flex-direction: column; align-items: center; gap: 8px; font-size: 13px; font-weight: 650; opacity: .9; }
    .preview { display: grid; grid-template-columns: repeat(3, 1fr); gap: 3px; width: 66px; aspect-ratio: 1; }
    .preview .cell { border-radius: 7px; cursor: default; }
    .done { display: flex; flex-direction: column; align-items: center; gap: 14px; }
    .done p { margin: 0; font-size: 18px; font-weight: 700; }
    .actions { display: flex; gap: 10px; flex-wrap: wrap; justify-content: center; }
    .btn { border: 0; border-radius: 999px; padding: 12px 24px; font: inherit; font-weight: 700; font-size: 15px; cursor: pointer;
      background: var(--fg); color: var(--shape); transition: transform .12s ease; }
    .btn:hover { transform: translateY(-1px); }
    .btn.ghost { background: transparent; color: var(--fg); box-shadow: inset 0 0 0 2px var(--fg); }
    button:focus-visible { outline: 3px solid var(--fg); outline-offset: 3px; }
    @media (prefers-reduced-motion: reduce) { .content { transition: none; } .cell .q { transition: none; } }
  `;

  function parseColor(c) {
    const m = String(c).match(/rgba?\(([^)]+)\)/);
    if (m) { const [r, g, b, a = 1] = m[1].split(/[ ,/]+/).filter(Boolean).map(Number); return { r, g, b, a }; }
    const x = String(c).replace('#', '');
    if (x.length === 6) return { r: parseInt(x.slice(0, 2), 16), g: parseInt(x.slice(2, 4), 16), b: parseInt(x.slice(4, 6), 16), a: 1 };
    return { r: 255, g: 255, b: 255, a: 1 };
  }

  function readableOn(hex) {
    const { r, g, b } = parseColor(hex);
    const lin = (v) => { v /= 255; return v <= 0.03928 ? v / 12.92 : ((v + 0.055) / 1.055) ** 2.4; };
    const L = 0.2126 * lin(r) + 0.7152 * lin(g) + 0.0722 * lin(b);
    const dark = '#14161c';
    return 1.05 / (L + 0.05) > (L + 0.05) / 0.0579 ? '#ffffff' : dark; // 0.0579 = 0.05 + luminance of the dark ink
  }

  function pageBg() {
    for (const el of [document.body, document.documentElement]) {
      if (!el) continue;
      const c = getComputedStyle(el).backgroundColor;
      const p = parseColor(c);
      if (c && p.a > 0.05) return c;
    }
    // no explicit page background: the browser paints the canvas from the page's declared color-scheme
    const scheme = getComputedStyle(document.documentElement).colorScheme || '';
    const dark = /\bdark\b/.test(scheme) && !/\blight\b/.test(scheme);
    return dark ? '#121212' : '#ffffff';
  }

  // Each shape is sized so that, fully scaled, it covers the whole viewport.
  function shapeSpec(name) {
    const vw = innerWidth, vh = innerHeight;
    switch (name) {
      case 'diamond':
        return { clip: 'polygon(50% 0, 100% 50%, 50% 100%, 0 50%)', size: (vw + vh) * 1.03, ay: 50 };
      case 'triangle': {
        const size = (vw + vh) * 1.06;
        return { clip: 'polygon(50% 0, 100% 100%, 0 100%)', size, ay: ((vw + vh * 0.5 + 0.02 * size) / size) * 100 };
      }
      case 'hexagon':
        return { clip: 'polygon(25% 3%, 75% 3%, 100% 50%, 75% 97%, 25% 97%, 0 50%)', size: Math.hypot(vw, vh) * 1.22, ay: 50 };
      default:
        return { clip: 'circle(50% at 50% 50%)', size: Math.hypot(vw, vh) * 1.04, ay: 50 };
    }
  }

  function pauseMedia() {
    document.querySelectorAll('video,audio').forEach((m) => { try { if (!m.paused) m.pause(); } catch { /* ignore */ } });
  }

  // Players call play() again on their own (autoplay, "next video"): stop them the instant they try.
  function stopPlayback(e) { const m = e.target; if (m && (m.tagName === 'VIDEO' || m.tagName === 'AUDIO')) { try { m.pause(); } catch { /* ignore */ } } }

  function swallowKeys(e) { e.stopImmediatePropagation(); } // keep page shortcuts (space, k, j...) from firing under the overlay

  function showOverlay(m) {
    if (overlay || !alive) return;
    const bg = pageBg();
    const fg = readableOn(m.color);
    const spec = shapeSpec(m.shape);
    const reduce = matchMedia('(prefers-reduced-motion: reduce)').matches;

    const host = document.createElement('lockin-ai-overlay');
    host.style.cssText = 'all:initial;position:fixed;inset:0;z-index:2147483647;display:block;';
    const root = host.attachShadow({ mode: 'closed' });
    try {
      const sheet = new CSSStyleSheet();
      sheet.replaceSync(CSS);
      root.adoptedStyleSheets = [sheet];
    } catch {
      root.append(h('style', {}, CSS));
    }

    const shape = h('div', { class: 'shape' });
    shape.style.cssText =
      `width:${spec.size}px;height:${spec.size}px;left:50%;top:50%;` +
      `margin-left:${-spec.size / 2}px;margin-top:${-spec.size * spec.ay / 100}px;` +
      `transform-origin:50% ${spec.ay}%;clip-path:${spec.clip};`;

    const why = m.reason === 'goal'
      ? `This page doesn't look related to your goal${m.goalTitle ? `: ${m.goalTitle}` : ''}.`
      : `You've reached your engagement limit on ${m.host}.`;
    const gameBox = h('div', { class: 'game' });
    const bottom = h('div', { class: 'bottom' }, h('p', { class: 'hint' }, 'Solve this to settle your mind.'), gameBox);
    const content = h('div', { class: 'content' },
      h('div', { class: 'top' },
        h('span', { class: 'chip' }, m.category),
        h('p', { class: 'quote' }, m.quote),
        h('p', { class: 'why' }, why)),
      bottom);
    const stage = h('div', { class: 'stage' }, shape, content);
    stage.style.cssText = `--bg:${bg};--fg:${fg};--shape:${m.color};`;
    root.append(stage);
    document.documentElement.append(host);

    const prevOverflow = document.documentElement.style.getPropertyValue('overflow');
    document.documentElement.style.setProperty('overflow', 'hidden', 'important');
    if (document.body) document.body.inert = true;
    const onReady = () => {
      if (!overlay) return;
      if (document.body) document.body.inert = true;
      stage.style.setProperty('--bg', pageBg());
    };
    document.addEventListener('DOMContentLoaded', onReady, { once: true });

    ['keydown', 'keyup', 'keypress'].forEach((t) => window.addEventListener(t, swallowKeys, true));
    try { if (document.fullscreenElement) document.exitFullscreen(); } catch { /* ignore */ }
    try { if (document.pictureInPictureElement) document.exitPictureInPicture(); } catch { /* ignore */ }
    pauseMedia();
    document.addEventListener('play', stopPlayback, true);
    document.addEventListener('playing', stopPlayback, true);
    const mediaTimer = setInterval(pauseMedia, 800);
    const guard = new MutationObserver(() => { if (!host.isConnected) document.documentElement.append(host); });
    guard.observe(document.documentElement, { childList: true });

    overlay = { host, stage, mediaTimer, guard, prevOverflow };

    // The shape grows from the center until it fills the page, then the quote and puzzle fade in.
    let revealed = false;
    const reveal = () => {
      if (revealed || !overlay) return;
      revealed = true;
      stage.style.background = m.color;
      content.classList.add('show');
      const onSolved = () => {
        const label = m.reason === 'goal' ? 'Nice. Ready to get back to it?' : 'Nice. Breathe out.';
        const actions = m.reason === 'goal'
          ? [
              h('button', { class: 'btn', onclick: leave }, 'Back to my goal'),
              h('button', { class: 'btn ghost', onclick: allowPage }, 'This page is relevant')
            ]
          : [h('button', { class: 'btn', onclick: resume }, 'Back to browsing')];
        bottom.replaceChildren(h('div', { class: 'done' }, h('p', {}, label), h('div', { class: 'actions' }, actions)));
        bottom.querySelector('button')?.focus();
      };
      (G[m.game] || G.slide)(gameBox, onSolved);
    };
    const resume = () => { send({ type: 'resume', reason: 'engagement', page: info() }); hideOverlay(); };
    const allowPage = () => { send({ type: 'resume', reason: 'goal', allow: true, page: info() }); hideOverlay(); };
    const leave = () => {
      hideOverlay();
      if (history.length > 1) history.back();
      else send({ type: 'leave' });
    };

    const anim = shape.animate(
      [{ transform: 'scale(0)' }, { transform: 'scale(1)' }],
      { duration: reduce ? 500 : 2600, easing: 'cubic-bezier(0.45, 0.05, 0.25, 1)', fill: 'forwards' }
    );
    anim.finished.then(reveal, reveal);
  }

  function hideOverlay() {
    if (!overlay) return;
    const { host, mediaTimer, guard, prevOverflow } = overlay;
    overlay = null;
    clearInterval(mediaTimer);
    guard.disconnect();
    document.removeEventListener('play', stopPlayback, true);
    document.removeEventListener('playing', stopPlayback, true);
    ['keydown', 'keyup', 'keypress'].forEach((t) => window.removeEventListener(t, swallowKeys, true));
    host.remove();
    if (prevOverflow) document.documentElement.style.setProperty('overflow', prevOverflow);
    else document.documentElement.style.removeProperty('overflow');
    if (document.body) document.body.inert = false;
    st.lastTick = Date.now();
  }
})();
