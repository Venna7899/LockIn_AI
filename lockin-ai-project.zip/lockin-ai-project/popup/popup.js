import { AREAS, AREA_META, DEFAULT_SETTINGS, DEFAULT_EB } from '../lib/config.js';
import { validateKey } from '../lib/gemini.js';

const $ = (s) => document.querySelector(s);
const $$ = (s) => [...document.querySelectorAll(s)];
const ORIGINS = ['http://*/*', 'https://*/*'];
const esc = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const send = (m) => chrome.runtime.sendMessage(m).catch(() => ({ ok: false, error: 'LockIn AI is restarting. Try again.' }));

const MARK = '<svg viewBox="0 0 100 100" aria-hidden="true"><polygon points="50,0 75,25 50,50 25,25" fill="#545863"/><polygon points="25,25 50,50 25,75 0,50" fill="#F96E46"/><polygon points="75,25 100,50 75,75 50,50" fill="#F9C846"/><polygon points="50,50 75,75 50,100 25,75" fill="#00E8FC"/></svg>';
$$('[data-mark]').forEach((el) => { el.innerHTML = MARK; });

const AREA_INFO = {
  focus:       { ink: '#ffffff', by: 'Marcus Aurelius', quote: 'Ask yourself at every moment, \u2018Is this necessary?\u2019' },
  consistency: { ink: '#1b1d26', by: 'Aristotle',       quote: 'Virtue comes about as a result of habit.' },
  ambition:    { ink: '#1b1d26', by: 'Serena Williams', quote: 'I\u2019m not going to relax. There\u2019s so much more for me.' },
  achievement: { ink: '#1b1d26', by: 'Nelson Mandela',  quote: 'It always seems impossible until it\u2019s done.' }
};

const SHAPE_ICONS = {
  auto: '<path d="M12 2l2.4 7.6L22 12l-7.6 2.4L12 22l-2.4-7.6L2 12l7.6-2.4z"/>',
  circle: '<circle cx="12" cy="12" r="9.5"/>',
  diamond: '<polygon points="12,1.5 22.5,12 12,22.5 1.5,12"/>',
  triangle: '<polygon points="12,3 22.5,21 1.5,21"/>',
  hexagon: '<polygon points="7,3 17,3 23,12 17,21 7,21 1,12"/>'
};
const GAMES = { slide: 'Sliding tiles', lights: 'Lights out', match: 'Rotate to match' };

const S = {
  session: null, key: '', goal: null, settings: { ...DEFAULT_SETTINGS }, eb: { ...DEFAULT_EB },
  progress: null, job: null, keyError: false, access: false, accessAsked: false
};
let current = 'home';
let shown = null;
let busy = false;

/* ------------------------------------------------------------------ */
/* State                                                               */
/* ------------------------------------------------------------------ */

async function load() {
  const d = await chrome.storage.local.get(['session', 'geminiKey', 'goal', 'settings', 'eb', 'progress', 'job', 'keyError', 'accessAsked']);
  const uid = d.session?.user?.id;
  S.session = d.session || null;
  S.key = d.geminiKey || '';
  S.goal = d.goal && d.goal.owner === uid ? d.goal : null;
  S.settings = { ...DEFAULT_SETTINGS, ...(d.settings || {}) };
  S.eb = { ...DEFAULT_EB, ...(d.eb || {}) };
  S.progress = d.progress && d.progress.owner === uid ? d.progress : null;
  S.job = d.job || null;
  S.keyError = !!d.keyError;
  S.accessAsked = !!d.accessAsked;
  S.access = await chrome.permissions.contains({ origins: ORIGINS }).catch(() => false);
}

function gateView() {
  if (!S.session) return 'login';
  if (!S.key) return 'apikey';
  if (!S.access && !S.accessAsked) return 'access';
  return null;
}

function show(name) {
  current = name;
  render();
}

function render() {
  const gate = gateView();
  const gated = ['login', 'apikey', 'access'];
  const target = gate || (gated.includes(current) ? 'home' : current);
  if (target !== shown) {
    $$('.view').forEach((v) => { v.hidden = v.id !== `v-${target}`; });
    $(`#v-${target}`).scrollTop = 0;
    shown = target;
    if (target === 'eb') startMeterPoll(); else stopMeterPoll();
  }
  current = target;
  if (target === 'home') renderHome();
  if (target === 'goal') renderGoal();
  if (target === 'eb') renderEB();
  if (target === 'radar') renderRadarPage();
  if (target === 'settings') renderSettings();
  if (target === 'apikey') $('#btn-key-logout').hidden = false;
}

/* ------------------------------------------------------------------ */
/* Radar chart: a square rotated 45 degrees                            */
/* ------------------------------------------------------------------ */

const fmt = (v) => (v >= 10 ? String(Math.round(v)) : v.toFixed(1));

function radarSVG(p, { R, W, H, id }) {
  const cx = W / 2, cy = H / 2;
  const vals = AREAS.map((a) => Math.max(0, Math.min(100, Number(p?.[a]) || 0)));
  const dir = [[0, -1], [1, 0], [0, 1], [-1, 0]]; // Focus top, Consistency right, Ambition bottom, Achievement left
  const pt = (i, f) => [cx + dir[i][0] * R * f, cy + dir[i][1] * R * f];
  const poly = (pts) => pts.map((q) => q.map((n) => n.toFixed(1)).join(',')).join(' ');
  const f = vals.map((v) => Math.max(v, 3) / 100);
  const colors = AREAS.map((a) => AREA_META[a].color);
  const fs = R > 100 ? 15 : 13.5;

  let g = '';
  [0.25, 0.5, 0.75, 1].forEach((k) => {
    g += `<polygon points="${poly([0, 1, 2, 3].map((i) => pt(i, k)))}" fill="${k === 1 ? '#f7f8fc' : 'none'}" stroke="#e3e7f1" stroke-width="2"/>`;
  });
  AREAS.forEach((a, i) => {
    const [x, y] = pt(i, 1);
    g += `<line x1="${cx}" y1="${cy}" x2="${x.toFixed(1)}" y2="${y.toFixed(1)}" stroke="${colors[i]}" stroke-width="3" stroke-linecap="round" opacity=".4"/>`;
  });

  let defs = '', sectors = '';
  for (let i = 0; i < 4; i++) {
    const j = (i + 1) % 4;
    const [ax, ay] = pt(i, f[i]);
    const [bx, by] = pt(j, f[j]);
    defs += `<linearGradient id="${id}${i}" gradientUnits="userSpaceOnUse" x1="${ax.toFixed(1)}" y1="${ay.toFixed(1)}" x2="${bx.toFixed(1)}" y2="${by.toFixed(1)}"><stop offset="0" stop-color="${colors[i]}"/><stop offset="1" stop-color="${colors[j]}"/></linearGradient>`;
    sectors += `<polygon points="${cx},${cy} ${ax.toFixed(1)},${ay.toFixed(1)} ${bx.toFixed(1)},${by.toFixed(1)}" fill="url(#${id}${i})" fill-opacity=".62"/>`;
  }
  const outline = `<polygon points="${poly([0, 1, 2, 3].map((i) => pt(i, f[i])))}" fill="none" stroke="#1b1d26" stroke-width="2.5" stroke-linejoin="round"/>`;
  let dots = '', labels = '';
  AREAS.forEach((a, i) => {
    const [x, y] = pt(i, f[i]);
    dots += `<circle cx="${x.toFixed(1)}" cy="${y.toFixed(1)}" r="${R > 100 ? 8.5 : 7.5}" fill="${colors[i]}" stroke="#fff" stroke-width="3"/>`;
    const name = AREA_META[a].label, val = fmt(vals[i]);
    let x0 = cx, y0 = cy, anchor = 'middle';
    if (i === 0) y0 = cy - R - 30;
    if (i === 2) y0 = cy + R + 24;
    if (i === 1) { x0 = cx + R + 16; y0 = cy - 3; anchor = 'start'; }
    if (i === 3) { x0 = cx - R - 16; y0 = cy - 3; anchor = 'end'; }
    labels += `<text x="${x0}" y="${y0}" text-anchor="${anchor}" font-weight="800" font-size="${fs}" fill="#1b1d26">${name}</text>` +
              `<text x="${x0}" y="${y0 + fs + 2}" text-anchor="${anchor}" font-weight="650" font-size="${fs - 1.5}" fill="#666b7d">${val}</text>`;
  });
  return `<svg viewBox="0 0 ${W} ${H}" preserveAspectRatio="xMidYMid meet" role="img" aria-label="Radar chart. ${AREAS.map((a, i) => `${AREA_META[a].label} ${fmt(vals[i])}`).join(', ')}"><defs>${defs}</defs>${g}${sectors}${outline}${dots}${labels}</svg>`;
}

/* ------------------------------------------------------------------ */
/* Home                                                                */
/* ------------------------------------------------------------------ */

const ICON_CHECK = '<svg viewBox="0 0 24 24"><path d="M5 12.5l4.5 4.5L19 7.5"/></svg>';
const ICON_TRASH = '<svg viewBox="0 0 24 24"><path d="M4 7h16M9 7V4.5h6V7m-8 0 .8 12h8.4L17 7M10 11v5m4-5v5"/></svg>';

function renderHome() {
  $('#who').textContent = S.session?.user?.email || '';
  $('#key-banner').hidden = !S.keyError;
  $('#access-banner').hidden = S.access;
  $('#btn-eb').classList.toggle('on', S.eb.running);

  const card = $('#goal-card');
  if (!S.goal) {
    card.className = 'goal-slot';
    card.innerHTML = `<button class="empty-goal" id="btn-new-goal" type="button"><span class="plus" aria-hidden="true">+</span><span><strong>Set your goal</strong><span>Describe one, or let Gemini generate it.</span></span></button>`;
    $('#btn-new-goal').onclick = () => show('goal');
  } else {
    card.className = 'card goal';
    card.innerHTML = `
      <div class="goal-title">${esc(S.goal.title)}</div>
      <div class="goal-desc">${esc(S.goal.description)}</div>
      <div class="goal-meta"><span class="diff">Difficulty ${S.goal.difficulty}<span class="bar"><i style="width:${S.goal.difficulty}%"></i></span></span></div>
      <div class="goal-actions">
        <button type="button" id="btn-goal-done" aria-label="Mark goal achieved" title="Mark achieved">${ICON_CHECK}</button>
        <button type="button" class="del" id="btn-goal-del" aria-label="Delete goal" title="Delete goal">${ICON_TRASH}</button>
      </div>`;
    $('#btn-goal-done').onclick = async () => {
      const gain = (S.goal.difficulty / 10).toFixed(1);
      if (!(await ask(`Mark this goal as achieved? You'll earn +${gain} Achievement.`, 'Achieved'))) return;
      const r = await send({ type: 'goal:complete' });
      if (!r.ok) toastError(r.error);
    };
    $('#btn-goal-del').onclick = async () => {
      if (!(await ask('Delete this goal? Your radar scores stay as they are.', 'Delete'))) return;
      await send({ type: 'goal:delete' });
    };
  }
  $('#home-radar').innerHTML = radarSVG(S.progress, { R: 96, W: 440, H: 300, id: 'h' });
}

/* ------------------------------------------------------------------ */
/* Goal generator                                                      */
/* ------------------------------------------------------------------ */

function setTab(which) {
  const set = which === 'set';
  $('#tab-set').classList.toggle('on', set);
  $('#tab-gen').classList.toggle('on', !set);
  $('#tab-set').setAttribute('aria-selected', set);
  $('#tab-gen').setAttribute('aria-selected', !set);
  $('#f-set').hidden = !set;
  $('#f-gen').hidden = set;
}

function renderGoal() {
  const job = S.job;
  const status = job?.status;
  $('#goal-forms').hidden = !!job;
  $('#goal-spinner').hidden = status !== 'running';
  const out = $('#goal-result');
  out.hidden = !job || status === 'running';
  if (!job || status === 'running') { out.innerHTML = ''; return; }

  if (status === 'done') {
    const g = job.result;
    out.innerHTML = `
      <div class="goal-preview">
        <div class="card">
          <h3>${esc(g.title)}</h3>
          <p>${esc(g.description)}</p>
          <div class="big-diff"><b>${g.difficulty}</b><span class="bar"><i style="width:${g.difficulty}%"></i></span></div>
          <p class="why">Difficulty out of 100. ${esc(g.difficultyReasoning)}</p>
        </div>
        ${S.goal ? '<p class="fine">This replaces your current goal.</p>' : ''}
        <p class="error" id="commit-error" hidden></p>
        <div class="row">
          <button class="btn ghost small" id="btn-redo" type="button">Start over</button>
          <button class="btn primary small" id="btn-commit" type="button">Set as my goal</button>
        </div>
      </div>`;
    $('#btn-redo').onclick = () => send({ type: 'job:cancel' });
    $('#btn-commit').onclick = commitGoal;
  } else if (status === 'rejected') {
    out.innerHTML = `
      <div class="card msg-card">
        <div class="mark sm" data-mark></div>
        <h3>That one's not for me</h3>
        <p>I can't help with that goal. Try something else.</p>
        <button class="btn primary small" id="btn-redo" type="button">Try something else</button>
      </div>`;
    out.querySelectorAll('[data-mark]').forEach((el) => { el.innerHTML = MARK; });
    $('#btn-redo').onclick = () => send({ type: 'job:cancel' });
  } else {
    out.innerHTML = `
      <div class="card msg-card">
        <h3>Something went wrong</h3>
        <p>${esc(job.error || 'Please try again.')}</p>
        <button class="btn primary small" id="btn-redo" type="button">Go back</button>
      </div>`;
    $('#btn-redo').onclick = () => send({ type: 'job:cancel' });
  }
}

async function commitGoal() {
  if (busy) return;
  busy = true;
  const btn = $('#btn-commit');
  btn.disabled = true;
  const g = S.job.result;
  const r = await send({ type: 'goal:commit', goal: g });
  busy = false;
  if (!r.ok) {
    btn.disabled = false;
    const e = $('#commit-error');
    e.textContent = r.error || 'Could not save your goal.';
    e.hidden = false;
    return;
  }
  await send({ type: 'job:cancel' });
  show('home');
}

async function startJob(kind, input) {
  S.job = { status: 'running' };
  renderGoal();
  const r = await send({ type: 'job:start', job: { kind, input } });
  if (!r.ok) { S.job = { status: 'error', error: r.error }; renderGoal(); }
}

/* ------------------------------------------------------------------ */
/* Engagement bar page                                                 */
/* ------------------------------------------------------------------ */

let meterTimer = null;
function startMeterPoll() { stopMeterPoll(); pollMeter(); meterTimer = setInterval(pollMeter, 2000); }
function stopMeterPoll() { clearInterval(meterTimer); meterTimer = null; }

async function pollMeter() {
  const on = S.eb.running;
  $('#eb-meter').hidden = !on;
  $('#eb-meter-label').hidden = !on;
  if (!on) return;
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true }).catch(() => []);
  const r = tab?.id != null ? await send({ type: 'eb:meter', tabId: tab.id }) : null;
  const fill = $('#eb-fill');
  if (!r?.ok || !r.host) {
    fill.style.width = '0%';
    $('#eb-meter-label').textContent = 'Open a website to see its bar fill.';
    return;
  }
  fill.style.width = `${r.value}%`;
  fill.classList.toggle('hot', r.value >= S.eb.threshold * 0.8);
  $('#eb-line').style.left = `calc(${S.eb.threshold}% - 1.5px)`;
  $('#eb-meter-label').textContent = `${r.host}: ${r.value} of ${S.eb.threshold}`;
}

function renderEB() {
  const range = $('#eb-range');
  if (document.activeElement !== range) range.value = S.eb.threshold;
  $('#eb-value').textContent = range.value;
  const btn = $('#btn-eb-toggle');
  btn.textContent = S.eb.running ? 'Stop' : 'Start';
  btn.classList.toggle('running', S.eb.running);
  $('#eb-meter').hidden = !S.eb.running;
  $('#eb-meter-label').hidden = !S.eb.running;
  $('#eb-line').style.left = `calc(${S.eb.threshold}% - 1.5px)`;
}

/* ------------------------------------------------------------------ */
/* Radar details                                                       */
/* ------------------------------------------------------------------ */

function renderRadarPage() {
  $('#big-radar').innerHTML = radarSVG(S.progress, { R: 112, W: 480, H: 330, id: 'b' });
  $('#area-list').innerHTML = AREAS.map((a) => {
    const info = AREA_INFO[a];
    const v = Number(S.progress?.[a]) || 0;
    return `<div class="area" style="--c:${AREA_META[a].color};--vc:${info.ink}">
      <div class="swatch"></div>
      <div>
        <div class="top"><span class="name">${AREA_META[a].label}</span><span class="val">${fmt(v)}</span></div>
        <q>${esc(info.quote)}</q>
        <span class="by">${esc(info.by)}</span>
      </div>
    </div>`;
  }).join('') + '<p class="fine">Focus grows with on-task time, Consistency with daily progress, Ambition with harder goals and Achievement with finished goals.</p>';
}

/* ------------------------------------------------------------------ */
/* Settings                                                            */
/* ------------------------------------------------------------------ */

function renderSettings() {
  const sel = S.settings.shape;
  $('#shape-grid').innerHTML = ['auto', 'circle', 'diamond', 'triangle', 'hexagon'].map((s) =>
    `<button type="button" class="shape-opt" data-shape="${s}" aria-pressed="${sel === s}"><svg viewBox="0 0 24 24" aria-hidden="true">${SHAPE_ICONS[s]}</svg>${s === 'auto' ? 'Auto' : s[0].toUpperCase() + s.slice(1)}</button>`).join('');
  $$('.shape-opt').forEach((b) => { b.onclick = () => chrome.storage.local.set({ settings: { ...S.settings, shape: b.dataset.shape } }); });

  const on = new Set(S.settings.games);
  $('#game-chips').innerHTML = Object.entries(GAMES).map(([id, label]) =>
    `<label class="chip"><input type="checkbox" value="${id}" ${on.has(id) ? 'checked' : ''} ${on.size === 1 && on.has(id) ? 'disabled' : ''}><span>${label}</span></label>`).join('');
  $$('#game-chips input').forEach((i) => {
    i.onchange = () => {
      const next = new Set(S.settings.games);
      if (i.checked) next.add(i.value); else next.delete(i.value);
      if (next.size) chrome.storage.local.set({ settings: { ...S.settings, games: [...next] } });
    };
  });

  $('#key-mask').textContent = S.key ? `Current key ends in ${S.key.slice(-4)}` : 'No key saved';
  $('#acct-email').textContent = S.session?.user?.email || '';
  $('#access-status').textContent = S.access ? 'On. Blocking can run on the sites you visit.' : 'Off. Blocking is paused.';
  $('#btn-access-toggle').textContent = S.access ? 'Turn off' : 'Allow';
}

/* ------------------------------------------------------------------ */
/* Dialogs + helpers                                                   */
/* ------------------------------------------------------------------ */

function ask(text, yes = 'Confirm') {
  return new Promise((resolve) => {
    $('#modal-text').textContent = text;
    $('#modal-yes').textContent = yes;
    $('#modal').hidden = false;
    $('#modal-yes').focus();
    const done = (v) => { $('#modal').hidden = true; $('#modal-yes').onclick = $('#modal-no').onclick = null; resolve(v); };
    $('#modal-yes').onclick = () => done(true);
    $('#modal-no').onclick = () => done(false);
  });
}

function toastError(msg) { ask(msg || 'Something went wrong.', 'OK').then(() => {}); }

// Must be called straight from a click handler: Chrome only shows the prompt after a user gesture.
async function requestAccess() {
  try {
    const granted = await chrome.permissions.request({ origins: ORIGINS });
    await chrome.storage.local.set({ accessAsked: true });
    return granted;
  } catch {
    return false;
  }
}

/* ------------------------------------------------------------------ */
/* Wiring                                                              */
/* ------------------------------------------------------------------ */

function wire() {
  // login
  $('#btn-google').onclick = async () => {
    const label = $('#google-label'), err = $('#login-error');
    err.hidden = true;
    $('#btn-google').disabled = true;
    label.textContent = 'Opening Google\u2026';
    const r = await send({ type: 'auth:login' });
    $('#btn-google').disabled = false;
    label.textContent = 'Continue with Google';
    if (!r.ok) {
      const msg = r.error || '';
      err.textContent = /did not approve|closed|cancel/i.test(msg)
        ? 'Sign-in was cancelled. Try again when you are ready.'
        : /database error/i.test(msg)
          ? 'Supabase could not create your account: something in your database is rejecting new users. Run the latest supabase_setup.sql (see SETUP.md, Troubleshooting).'
          : (msg || 'Sign-in failed. Please try again.');
      err.hidden = false;
    }
    await load(); render();
  };

  // api key
  const keyInput = $('#key-input');
  $('#key-toggle').onclick = () => {
    const hide = keyInput.type === 'password';
    keyInput.type = hide ? 'text' : 'password';
    $('#key-toggle').textContent = hide ? 'Hide' : 'Show';
  };
  const saveKey = async (input, errEl, btn) => {
    const key = input.value.trim();
    errEl.hidden = true;
    if (key.length < 20) { errEl.textContent = 'That key looks too short. Copy it again from Google AI Studio.'; errEl.hidden = false; return false; }
    btn.disabled = true;
    try {
      await validateKey(key);
      await chrome.storage.local.set({ geminiKey: key });
      await chrome.storage.local.remove('keyError');
      input.value = '';
      return true;
    } catch (e) {
      errEl.textContent = e.code === 'network' ? e.message : 'Google did not accept that key. Check you copied all of it.';
      errEl.hidden = false;
      return false;
    } finally { btn.disabled = false; }
  };
  $('#btn-key-save').onclick = async () => { if (await saveKey(keyInput, $('#key-error'), $('#btn-key-save'))) { await load(); render(); } };
  keyInput.addEventListener('keydown', (e) => { if (e.key === 'Enter') $('#btn-key-save').click(); });
  $('#btn-key-logout').onclick = () => logout();

  // site access
  const grant = async (errId) => {
    const ok = await requestAccess();
    await load();
    if (!ok) {
      const e = $(errId);
      if (e) { e.textContent = 'Access was not granted, so blocking stays off. You can allow it any time.'; e.hidden = false; }
    }
    render();
  };
  $('#btn-access').onclick = () => grant('#access-error');
  $('#btn-access-skip').onclick = async () => { await chrome.storage.local.set({ accessAsked: true }); await load(); render(); };
  $('#btn-banner-access').onclick = () => grant('#access-error');
  $('#btn-access-toggle').onclick = async () => {
    if (S.access) await chrome.permissions.remove({ origins: ORIGINS });
    else await requestAccess();
    await load(); render();
  };

  // home
  $('#radar-card').onclick = () => show('radar');
  $('#btn-eb').onclick = () => show('eb');
  $('#btn-settings').onclick = () => show('settings');
  $('#btn-banner-fix').onclick = () => show('settings');
  $$('[data-home]').forEach((b) => { b.onclick = () => show('home'); });

  // goal forms
  $('#tab-set').onclick = () => setTab('set');
  $('#tab-gen').onclick = () => setTab('gen');
  $('#g-goal').addEventListener('input', (e) => { $('#g-count').textContent = `${e.target.value.length} / 400`; });
  $('#f-set').addEventListener('submit', (e) => {
    e.preventDefault();
    startJob('analyze', {
      goal: $('#g-goal').value, aim: $('#g-aim').value,
      amount: $('#g-amount').value, unit: $('#g-unit').value, hoursPerWeek: $('#g-hours').value
    });
  });
  $('#f-gen').addEventListener('submit', (e) => {
    e.preventDefault();
    startJob('generate', {
      interests: $('#n-interests').value, hoursPerWeek: $('#n-hours').value,
      expertise: document.querySelector('input[name="exp"]:checked').value,
      horizon: document.querySelector('input[name="hor"]:checked').value
    });
  });
  $('#btn-job-cancel').onclick = () => send({ type: 'job:cancel' });

  // engagement bar
  const range = $('#eb-range');
  let t;
  range.addEventListener('input', () => {
    $('#eb-value').textContent = range.value;
    clearTimeout(t);
    t = setTimeout(() => chrome.storage.local.set({ eb: { ...S.eb, threshold: Number(range.value) } }), 250);
  });
  $('#btn-eb-toggle').onclick = async () => {
    if (S.eb.running) { await chrome.storage.local.set({ eb: { ...S.eb, running: false } }); return; }
    if (!S.access && !(await requestAccess())) {
      $('#eb-meter-label').hidden = false;
      $('#eb-meter-label').textContent = 'Allow site access so the Engagement Bar can work.';
      await load(); render();
      return;
    }
    await chrome.storage.local.set({ eb: { running: true, threshold: Number(range.value) } });
  };

  // settings
  $('#btn-set-key').onclick = async () => {
    const msg = $('#set-key-msg');
    const ok = await saveKey($('#set-key'), msg, $('#btn-set-key'));
    if (ok) { msg.textContent = 'Key saved.'; msg.hidden = false; msg.classList.remove('error'); } else msg.classList.add('error');
    await load(); render();
  };
  $('#btn-logout').onclick = () => logout();
}

async function logout() {
  if (!(await ask('Log out? Your Gemini API key will be deleted from this device.', 'Log out'))) return;
  await send({ type: 'auth:logout' });
  await load();
  current = 'home';
  render();
}

/* ------------------------------------------------------------------ */
/* Boot                                                                */
/* ------------------------------------------------------------------ */

chrome.storage.onChanged.addListener(async () => { await load(); render(); });
chrome.permissions.onAdded.addListener(async () => { await load(); render(); });
chrome.permissions.onRemoved.addListener(async () => { await load(); render(); });

(async function init() {
  wire();
  await load();
  if (S.job) current = 'goal';
  render();
  if (S.session) send({ type: 'sync:pull' });
})();
