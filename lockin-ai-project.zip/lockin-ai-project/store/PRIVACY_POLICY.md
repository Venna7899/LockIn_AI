# LockIn AI Privacy Policy

Last updated: October 4, 2026
Contact: [YOUR EMAIL ADDRESS]

LockIn AI is a Chrome extension that helps you stay focused by blocking websites that are too
engaging or unrelated to your goal. This policy explains what it handles and why.

## What stays on your device
- **Your Gemini API key.** Stored only in your browser's extension storage. It is never sent to
  LockIn AI or to our database. It is deleted every time you log out.
- **Your current goal** (title, description, difficulty and related keywords) and your settings.
- **Engagement signals.** While Engagement Bar mode runs, the extension measures time on a page,
  scrolling, clicks and whether video is playing, in your browser, to fill a per-site bar. These
  measurements are not uploaded and are cleared when you close the browser.

## What is stored on our servers (Supabase)
- Your Google account identifier, email address and name, used to sign you in.
- Your radar chart scores (Focus, Consistency, Ambition, Achievement) and the difficulty rating of
  your most recent goal.

Each user can only read and change their own row (row level security).

## What is sent to Google Gemini
When you add or generate a goal, the text you type is sent to the Gemini API using **your own API key**.
While you have a goal, LockIn AI also sends, for each page you open, the page's **site name, path (without
the part after "?"), title and short description** to Gemini to decide whether the page fits your goal.
Page contents, form entries, passwords and messages are never read or sent. Google processes this under
its own terms and privacy policy. Without a goal, nothing is sent to Gemini.

## What we do not do
We do not sell or share your data, show ads, use analytics or tracking, or load remotely hosted code.
Data is used only to provide the features described above.

## Your choices
- Log out any time to delete your Gemini key and local account data.
- Turn off site access in Settings (or at chrome://extensions) to stop all on-page features.
- To delete your server-side data, email the contact address above from your account email.

## Changes
If this policy changes we will update the date above.
