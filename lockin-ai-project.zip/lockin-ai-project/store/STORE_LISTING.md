# Chrome Web Store: copy to paste

## Store listing tab
**Name:** LockIn AI
**Category:** Productivity
**Language:** English

**Summary (max 132 chars):**
Block over-engaging and off-goal sites. Set an AI-rated goal, watch your focus grow, and reset with a calming puzzle.

**Description:**
LockIn AI helps you take your attention back.

ENGAGEMENT BAR MODE
Pick a limit from 1 to 100. Every site gets its own bar that fills with time, scrolling, autoplay video and endless feeds, and drains when you step away. When a site reaches your limit, the page is covered and you get a short spatial puzzle to settle down before you continue.

GOAL MODE
Describe your goal (or let Gemini generate one from your interests, time and level). Gemini turns it into a specific description and rates its difficulty out of 100. While you have a goal, pages that do not relate to it are covered with the same calm-down screen.

YOUR RADAR
Four areas grow as you work: Focus, Consistency, Ambition and Achievement. Open the chart for a closer look.

PRIVACY
- Uses your own Gemini API key. It stays on your device and is deleted when you log out.
- Page text, forms and passwords are never read. In Goal mode a page's site name, path, title and short description are sent to Gemini to check relevance.
- Site access is requested only after you sign in, and you can turn it off in Settings.
- Sign in with Google. Only your radar scores and latest goal difficulty are stored on our server.

## Privacy tab
**Single purpose:**
Help users stay focused by covering websites that are too engaging or unrelated to the user's goal.

**Permission justifications:**
- storage: saves the user's settings, current goal, session and Gemini API key locally.
- identity: opens the Google sign-in window (chrome.identity.launchWebAuthFlow) and builds the redirect URL.
- alarms: wakes the background worker once a minute to sync radar progress and hourly to close finished days.
- scripting: registers the on-page content script after the user grants site access, and injects it into tabs that were already open.
- Host permission supabase.co project: sign-in and saving the user's radar scores.
- Host permission generativelanguage.googleapis.com: sends goal text and page title/path/description to the Gemini API with the user's own key.
- Optional host permissions http://*/* and https://*/*: requested at runtime, only when the user taps "Allow site access" after signing in. Required to measure engagement on the page the user is viewing and to draw the block screen on it. Not requested at install.

**Remote code:** No, I am not using remote code. All JavaScript is inside the package, unminified and unobfuscated.

**Data usage (check these):**
- Personally identifiable information (email, name via Google sign-in)
- Authentication information (Google session; Gemini API key stored locally and sent only to Google)
- Website content (page title, path and description sent to Gemini in Goal mode)
- Web history (page address and path used in Goal mode)

Certify: not sold to third parties; not used for purposes unrelated to the single purpose; not used for creditworthiness or lending.

**Privacy policy URL:** (the hosted copy of PRIVACY_POLICY.md)

## Test instructions tab (reviewers need these or the review stalls)
Sign-in uses Google. Test account: [EMAIL] / [PASSWORD] (an account with 2-step verification off).
Gemini key for testing: [TEMPORARY KEY] (from https://aistudio.google.com/apikey).
1. Click the toolbar icon → Continue with Google → sign in with the test account.
2. Paste the Gemini key → Continue. Tap "Allow site access" and confirm Chrome's prompt.
3. Home → Engagement Bar Mode → set the limit to 1 → Start. Open any site and scroll for about 10 seconds: a shape expands, a quote and a puzzle appear.
4. Home → Set your goal → "I have a goal" → fill the fields → Analyze → Set as my goal. Open an unrelated site (for example a news site): it is covered.
